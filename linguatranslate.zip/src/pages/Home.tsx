import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Sparkles, ArrowRight, ShieldCheck, Cpu, Volume2, BookmarkCheck, FileText, Mic, Radio, Search, Download } from "lucide-react";
import Translator from "../components/Translator";
import VoiceConversation from "../components/VoiceConversation";
import History from "../components/History";
import { TranslationHistoryItem } from "../types";
import { User } from "firebase/auth";
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, writeBatch } from "firebase/firestore";
import { db } from "../lib/firebase";

interface HomeProps {
  user: User | null;
  onSignIn: () => void;
}

export default function Home({ user, onSignIn }: HomeProps) {
  const [activeTab, setActiveTab] = useState<"text" | "voice">("text");
  // Local storage history for unauthenticated users
  const [localHistory, setLocalHistory] = useState<TranslationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem("translation_history");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Failed to parse translation history:", e);
      return [];
    }
  });

  // Cloud Firestore history for authenticated users
  const [firestoreHistory, setFirestoreHistory] = useState<TranslationHistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const [revisitItem, setRevisitItem] = useState<TranslationHistoryItem | null>(null);

  // Active history is determined by whether the user is authenticated
  const history = user ? firestoreHistory : localHistory;

  // Persist localHistory to localStorage when changed
  useEffect(() => {
    if (!user) {
      try {
        localStorage.setItem("translation_history", JSON.stringify(localHistory));
      } catch (e) {
        console.error("Failed to write translation history to localStorage:", e);
      }
    }
  }, [localHistory, user]);

  // Synchronize and load user's history from Firestore when authenticated
  useEffect(() => {
    if (!user) {
      setFirestoreHistory([]);
      return;
    }

    const fetchAndSyncHistory = async () => {
      setLoadingHistory(true);
      try {
        // 1. Check if there are local history items that need to be migrated to Firestore
        const savedLocal = localStorage.getItem("translation_history");
        const localItems: TranslationHistoryItem[] = savedLocal ? JSON.parse(savedLocal) : [];

        if (localItems.length > 0) {
          const batch = writeBatch(db);
          localItems.forEach((item) => {
            const docRef = doc(collection(db, "translations"));
            batch.set(docRef, {
              userId: user.uid,
              originalText: item.originalText,
              translatedText: item.translatedText,
              fromLang: item.fromLang,
              toLang: item.toLang,
              timestamp: item.timestamp,
              createdAt: item.createdAt || Date.now()
            });
          });
          await batch.commit();
          
          // Clear local storage as they are now securely migrated to user's account
          localStorage.removeItem("translation_history");
          setLocalHistory([]);
        }

        // 2. Query all translation docs of the user in Firestore
        const q = query(collection(db, "translations"), where("userId", "==", user.uid));
        const querySnapshot = await getDocs(q);
        const fetchedItems: TranslationHistoryItem[] = [];
        
        querySnapshot.forEach((document) => {
          const data = document.data();
          fetchedItems.push({
            id: document.id,
            originalText: data.originalText || "",
            translatedText: data.translatedText || "",
            fromLang: data.fromLang || "",
            toLang: data.toLang || "",
            timestamp: data.timestamp || "",
            createdAt: data.createdAt || 0
          });
        });

        // Sort in memory (newer items first) to bypass composite index requirements
        fetchedItems.sort((a, b) => {
          const timeA = a.createdAt || 0;
          const timeB = b.createdAt || 0;
          return timeB - timeA;
        });

        // Keep top 50 items for user interface presentation
        setFirestoreHistory(fetchedItems.slice(0, 50));
      } catch (error) {
        console.error("Error synchronizing with Firestore:", error);
      } finally {
        setLoadingHistory(false);
      }
    };

    fetchAndSyncHistory();
  }, [user]);

  const handleAddHistory = async (item: Omit<TranslationHistoryItem, "id" | "timestamp">) => {
    const timestampStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " - " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });
    const createdAtMs = Date.now();

    if (user) {
      try {
        const docRef = await addDoc(collection(db, "translations"), {
          userId: user.uid,
          originalText: item.originalText,
          translatedText: item.translatedText,
          fromLang: item.fromLang,
          toLang: item.toLang,
          timestamp: timestampStr,
          createdAt: createdAtMs
        });

        const newItem: TranslationHistoryItem = {
          ...item,
          id: docRef.id,
          timestamp: timestampStr,
          createdAt: createdAtMs
        };

        setFirestoreHistory((prev) => {
          const filtered = prev.filter(
            (h) => !(h.originalText.toLowerCase() === item.originalText.toLowerCase() && h.toLang === item.toLang)
          );
          return [newItem, ...filtered].slice(0, 50);
        });
      } catch (error) {
        console.error("Failed to add translation to Firestore:", error);
      }
    } else {
      const newItem: TranslationHistoryItem = {
        ...item,
        id: Math.random().toString(36).substring(2, 9),
        timestamp: timestampStr,
        createdAt: createdAtMs
      };

      setLocalHistory((prev) => {
        const filtered = prev.filter(
          (h) => !(h.originalText.toLowerCase() === item.originalText.toLowerCase() && h.toLang === item.toLang)
        );
        return [newItem, ...filtered].slice(0, 10); // Limit locally to 10
      });
    }
  };

  const handleDeleteHistory = async (id: string) => {
    if (user) {
      try {
        await deleteDoc(doc(db, "translations", id));
        setFirestoreHistory((prev) => prev.filter((item) => item.id !== id));
      } catch (error) {
        console.error("Failed to delete translation from Firestore:", error);
      }
    } else {
      setLocalHistory((prev) => prev.filter((item) => item.id !== id));
    }
  };

  const handleClearHistory = async () => {
    if (user) {
      try {
        const q = query(collection(db, "translations"), where("userId", "==", user.uid));
        const querySnapshot = await getDocs(q);
        
        const batch = writeBatch(db);
        querySnapshot.forEach((document) => {
          batch.delete(document.ref);
        });
        await batch.commit();
        
        setFirestoreHistory([]);
      } catch (error) {
        console.error("Failed to clear Firestore history:", error);
      }
    } else {
      setLocalHistory([]);
    }
  };

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen py-10 pb-20 bg-gradient-to-b from-gray-50/50 via-white to-gray-50/20 dark:from-gray-950 dark:via-gray-950/80 dark:to-gray-900/60 transition-colors duration-300"
    >
      
      {/* Hero Presentation Section */}
      <div className="max-w-4xl mx-auto text-center px-4 pt-4 pb-8 space-y-5">
        
        {/* Display Typography Title */}
        <div className="space-y-3">
          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-gray-900 dark:text-white"
          >
            Break barriers. <br />
            <span className="bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600 bg-clip-text text-transparent">
              Translate instantly.
            </span>
          </motion.h1>

          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="max-w-xl mx-auto text-base sm:text-lg text-gray-500 dark:text-gray-400 leading-relaxed font-medium"
          >
            Experience lightning-fast translations powered by advanced neural models, featuring real-time audio conversations, smart searchable filters, and complete privacy.
          </motion.p>
        </div>

      </div>

      {/* Main Workspace Bento Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left Column (Translator + Secondary Bento Boxes) */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Tab Selector */}
            <div className="flex items-center justify-between p-1.5 bg-gray-100/85 dark:bg-gray-900/50 border border-gray-200/50 dark:border-gray-800/80 rounded-2xl w-full max-w-md">
              <button
                id="text-tab-btn"
                onClick={() => setActiveTab("text")}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
                  activeTab === "text"
                    ? "bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 shadow-sm"
                    : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Text Translator</span>
              </button>
              
              <button
                id="voice-tab-btn"
                onClick={() => setActiveTab("voice")}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
                  activeTab === "voice"
                    ? "bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 shadow-sm"
                    : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                }`}
              >
                <Mic className="w-4 h-4" />
                <span className="relative">
                  Voice Assistant
                  <span className="absolute -top-1 -right-2 flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
                  </span>
                </span>
              </button>
            </div>

            {/* Bento Card 1: Translator Component */}
            <div className="bg-white/40 dark:bg-gray-900/10 border border-gray-100 dark:border-gray-800 rounded-3xl p-1 shadow-md hover:shadow-lg transition-all duration-300">
              {activeTab === "text" ? (
                <Translator 
                  onAddHistory={handleAddHistory} 
                  revisitItem={revisitItem}
                  onClearRevisit={() => setRevisitItem(null)}
                />
              ) : (
                <div className="p-4 md:p-6">
                  <div className="flex items-center gap-2 mb-6 border-b border-gray-100 dark:border-gray-900 pb-4">
                    <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-md shadow-blue-500/10">
                      <Mic className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-gray-800 dark:text-white">Real-Time Voice Conversation</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 leading-none mt-1 font-medium">Powered by Gemini 3.1 Live API</p>
                    </div>
                  </div>
                  <VoiceConversation onAddHistory={handleAddHistory} />
                </div>
              )}
            </div>

            {/* Secondary Row (Bento Grid of features) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Feature Bento 2 */}
              <div className="p-6 rounded-3xl border border-gray-100 dark:border-gray-800/80 bg-white/70 dark:bg-gray-900/40 backdrop-blur-xl flex flex-col justify-between gap-6 group hover:border-indigo-500/30 dark:hover:border-indigo-500/20 transition-all duration-300">
                <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 w-fit">
                  <Search className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">Instant Search Filters</h4>
                  <p className="text-xs text-gray-400 dark:text-gray-500 leading-relaxed mt-1 font-medium">Quickly locate your desired source or target languages by typing inside our intuitive searchable dropdown selectors.</p>
                </div>
              </div>

              {/* Feature Bento 3 (Premium Accent Card) */}
              <div className="p-6 rounded-3xl bg-slate-900 text-white dark:bg-slate-900 flex flex-col justify-between gap-6 group transition-all duration-300 shadow-lg shadow-slate-900/10">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase">Save Offline</span>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                </div>
                <div>
                  <div className="text-3xl font-black font-mono tracking-tight text-white flex items-baseline gap-1">
                    <span>CSV</span>
                    <span className="text-xs font-semibold text-slate-400 font-sans">Export Logs</span>
                  </div>
                  <h4 className="text-sm font-bold text-white mt-1.5">Portable Translation Logs</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mt-1 font-medium">Download and save your translation logs as structured CSV files anytime to keep secure records or study offline.</p>
                </div>
              </div>

            </div>

          </div>

          {/* Right Column (History Sidebar Bento Card) */}
          <div className="lg:col-span-4 flex flex-col">
            <div className="h-full flex flex-col bg-white/70 dark:bg-gray-900/40 backdrop-blur-xl border border-gray-100 dark:border-gray-800 rounded-3xl p-6 shadow-md hover:shadow-lg transition-all duration-300">
              <History
                history={history}
                onDeleteHistory={handleDeleteHistory}
                onClearHistory={handleClearHistory}
                onSelectHistoryItem={setRevisitItem}
                user={user}
                onSignIn={onSignIn}
                loading={loadingHistory}
              />
            </div>
          </div>

        </div>
      </div>

    </motion.main>
  );
}
