import axios from "axios";

export interface TranslationResponse {
  translation: string;
  error?: string;
  message?: string;
}

/**
 * Sends a translation request to our secure full-stack backend proxy API.
 * This guarantees that the VITE_RAPIDAPI_KEY is never exposed to the client browser.
 */
export async function translateText(
  text: string,
  from: string,
  to: string,
  engine: string = "auto"
): Promise<TranslationResponse> {
  if (!text || !text.trim()) {
    return { translation: "", error: "EMPTY_INPUT", message: "Please enter text to translate." };
  }

  try {
    const response = await axios.post("/api/translate", {
      from,
      to,
      text: text.trim(),
      engine
    });
    
    if (response.data && typeof response.data.translation === "string") {
      return { translation: response.data.translation };
    }
    
    return {
      translation: "",
      error: "UNEXPECTED_FORMAT",
      message: "The translation API returned an empty or unrecognized format."
    };
  } catch (error: any) {
    console.error("Frontend translation helper error:", error);
    
    if (error?.response?.data) {
      const backendError = error.response.data;
      return {
        translation: "",
        error: backendError.error || "API_FAILURE",
        message: backendError.message || "Failed to complete translation through proxy."
      };
    }
    
    return {
      translation: "",
      error: "NETWORK_ERROR",
      message: error?.message || "Could not connect to the translation service."
    };
  }
}
