import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import { Theme } from "./types";
import { auth, googleProvider } from "./lib/firebase";
import { onAuthStateChanged, signInWithPopup, signOut, User } from "firebase/auth";

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem("theme");
      if (saved === "light" || saved === "dark") return saved;
      
      // Default to light mode (as recommended: clean, high-contrast light theme first)
      return "light";
    } catch (e) {
      return "light";
    }
  });

  // User auth state tracking
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Sync theme with document class list
  useEffect(() => {
    try {
      const root = document.documentElement;
      if (theme === "dark") {
        root.classList.add("dark");
      } else {
        root.classList.remove("dark");
      }
      localStorage.setItem("theme", theme);
    } catch (e) {
      console.error("Failed to persist theme state:", e);
    }
  }, [theme]);

  // Auth subscriber
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Failed to sign in with Google:", error);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Failed to sign out:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors duration-300 font-sans selection:bg-blue-500/20">
      
      {/* Navigation */}
      <Navbar 
        theme={theme} 
        toggleTheme={toggleTheme} 
        user={user}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
      />

      {/* Pages Container */}
      <div className="flex-grow">
        {authLoading ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
            <div className="w-10 h-10 rounded-full border-4 border-blue-600 border-t-transparent animate-spin" />
            <p className="text-sm text-gray-400 dark:text-gray-500 font-bold font-mono tracking-wider uppercase">Loading Portal...</p>
          </div>
        ) : (
          <Home user={user} onSignIn={handleSignIn} />
        )}
      </div>

      {/* Dynamic Footer Section */}
      <footer 
        id="app-footer"
        className="w-full py-8 border-t border-gray-100 dark:border-gray-900 bg-gray-50/50 dark:bg-gray-950/40 text-center text-xs font-semibold text-gray-400 dark:text-gray-500 transition-colors duration-300"
      >
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 justify-center sm:justify-start">
            <span>Developed using React + Tailwind CSS + RapidAPI</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span>© {new Date().getFullYear()}</span>
            <span className="font-bold text-gray-700 dark:text-gray-300 bg-gray-200/50 dark:bg-gray-800/50 px-2 py-0.5 rounded-md">LinguaTranslate</span>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 px-1.5 py-0.5 rounded-full border border-indigo-500/10">v1.0.0</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
