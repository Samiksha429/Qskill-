export interface Language {
  code: string;
  name: string;
  flag: string;
}

export interface TranslationHistoryItem {
  id: string;
  originalText: string;
  translatedText: string;
  fromLang: string;
  toLang: string;
  timestamp: string;
  createdAt?: number;
}

export type Theme = "light" | "dark";
