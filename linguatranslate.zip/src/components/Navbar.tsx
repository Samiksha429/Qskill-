import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Languages, Menu, X, Globe, Sparkles, LogIn, LogOut, User as UserIcon } from "lucide-react";
import { Theme } from "../types";
import ThemeToggle from "./ThemeToggle";
import { User } from "firebase/auth";

interface NavbarProps {
  theme: Theme;
  toggleTheme: () => void;
  user: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
}

export default function Navbar({ theme, toggleTheme, user, onSignIn, onSignOut }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  return (
    <nav 
      id="main-navbar"
      className="sticky top-0 z-50 w-full bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl border-b border-gray-100 dark:border-gray-900 transition-colors duration-300"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Branding */}
          <div className="flex items-center space-x-3">
            <motion.div
              id="navbar-logo-icon"
              whileHover={{ rotate: 15, scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/20"
            >
              <Languages className="w-5.5 h-5.5" />
            </motion.div>
            
            <div>
              <span id="navbar-brand-name" className="text-xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">
                LinguaTranslate
              </span>
            </div>
          </div>

          {/* Desktop Navigation & Actions */}
          <div className="hidden md:flex items-center space-x-5">
            <a 
              href="#translator-card" 
              className="text-sm font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 transition-colors"
            >
              Translator
            </a>
            
            <a 
              href="#translation-history" 
              className="text-sm font-medium text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 transition-colors"
            >
              History
            </a>

            <div className="h-4 w-px bg-gray-200 dark:bg-gray-800" />

            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />

            <div className="h-4 w-px bg-gray-200 dark:bg-gray-800" />

            {/* Auth section */}
            {user ? (
              <div className="relative">
                <button
                  id="navbar-profile-trigger"
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-900 transition-colors cursor-pointer"
                  title={user.displayName || "User profile"}
                >
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || "User"}
                      className="w-8 h-8 rounded-full border border-blue-500/30 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-blue-500/10 text-blue-600 flex items-center justify-center font-bold">
                      {user.displayName ? user.displayName[0].toUpperCase() : <UserIcon className="w-4 h-4" />}
                    </div>
                  )}
                  <span className="text-xs font-semibold max-w-[80px] truncate text-gray-700 dark:text-gray-300">
                    {user.displayName?.split(" ")[0] || "Account"}
                  </span>
                </button>

                <AnimatePresence>
                  {showUserDropdown && (
                    <>
                      <div 
                        className="fixed inset-0 z-40" 
                        onClick={() => setShowUserDropdown(false)} 
                      />
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 10 }}
                        className="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-xl p-3 z-50 text-left"
                      >
                        <div className="px-2 py-1.5 border-b border-gray-100 dark:border-gray-800 mb-2">
                          <p className="text-xs font-bold text-gray-900 dark:text-white truncate">
                            {user.displayName}
                          </p>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate">
                            {user.email}
                          </p>
                        </div>
                        <button
                          id="btn-desktop-signout"
                          onClick={() => {
                            setShowUserDropdown(false);
                            onSignOut();
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-colors cursor-pointer"
                        >
                          <LogOut className="w-4 h-4" />
                          Sign Out
                        </button>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                id="btn-desktop-signin"
                onClick={onSignIn}
                className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/10 cursor-pointer transition-all"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sign In with Google
              </button>
            )}
          </div>

          {/* Mobile Right Controls */}
          <div className="flex md:hidden items-center space-x-3">
            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
            
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none cursor-pointer"
              aria-label="Toggle mobile menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-drawer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-t border-gray-100 dark:border-gray-900 bg-white dark:bg-gray-950 px-4 pt-3 pb-5 space-y-3 shadow-lg"
          >
            <div className="flex items-center space-x-2 text-xs text-gray-500 px-3 py-1 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <Globe className="w-3.5 h-3.5 text-blue-500" />
              <span>Real-time cloud-safe translations</span>
            </div>

            <a
              href="#translator-card"
              onClick={() => setIsOpen(false)}
              className="block px-3 py-2.5 rounded-xl text-base font-medium text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              Translator Interface
            </a>

            <a
              href="#translation-history"
              onClick={() => setIsOpen(false)}
              className="block px-3 py-2.5 rounded-xl text-base font-medium text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              History Log
            </a>

            <div className="border-t border-gray-100 dark:border-gray-900 pt-3">
              {user ? (
                <div className="space-y-3 px-3">
                  <div className="flex items-center gap-3">
                    {user.photoURL ? (
                      <img
                        src={user.photoURL}
                        alt="User"
                        className="w-10 h-10 rounded-full border border-blue-500/20 object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-blue-500/10 text-blue-600 flex items-center justify-center font-bold">
                        {user.displayName ? user.displayName[0].toUpperCase() : <UserIcon className="w-5 h-5" />}
                      </div>
                    )}
                    <div>
                      <p className="text-sm font-bold text-gray-900 dark:text-white truncate">{user.displayName}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{user.email}</p>
                    </div>
                  </div>
                  <button
                    id="btn-mobile-signout"
                    onClick={() => {
                      setIsOpen(false);
                      onSignOut();
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-rose-600 bg-rose-50 dark:bg-rose-950/20 hover:bg-rose-100 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out Account
                  </button>
                </div>
              ) : (
                <button
                  id="btn-mobile-signin"
                  onClick={() => {
                    setIsOpen(false);
                    onSignIn();
                  }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-blue-600 hover:bg-blue-700 text-white cursor-pointer transition-colors"
                >
                  <LogIn className="w-4 h-4" />
                  Sign In with Google
                </button>
              )}
            </div>

            <div className="pt-2 border-t border-gray-100 dark:border-gray-900 text-center text-[10px] text-gray-400 dark:text-gray-500">
              LinguaTranslate App v1.0.0
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

