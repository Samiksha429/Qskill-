import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Mic, MicOff, Volume2, VolumeX, Sparkles, AlertCircle, RefreshCcw, 
  Languages, GraduationCap, Smile, Radio, StopCircle
} from "lucide-react";

interface VoiceConversationProps {
  onAddHistory?: (item: { originalText: string; translatedText: string; fromLang: string; toLang: string }) => void;
}

export default function VoiceConversation({ onAddHistory }: VoiceConversationProps) {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [voice, setVoice] = useState("Zephyr"); // Puck, Charon, Kore, Fenrir, Zephyr
  const [mode, setMode] = useState("translator"); // translator, teacher, chat
  const [error, setError] = useState<string | null>(null);
  const [liveTranscription, setLiveTranscription] = useState<string[]>([]);
  const [isAssistantSpeaking, setIsAssistantSpeaking] = useState(false);

  // Audio Context and Stream References
  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const processorNodeRef = useRef<ScriptProcessorNode | null>(null);
  const audioSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const nextStartTimeRef = useRef<number>(0);
  const transcriptionEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll transcriptions
  useEffect(() => {
    if (transcriptionEndRef.current) {
      transcriptionEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [liveTranscription]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnectSession();
    };
  }, []);

  const voices = [
    { id: "Zephyr", name: "Zephyr (Warm)" },
    { id: "Kore", name: "Kore (Clear)" },
    { id: "Puck", name: "Puck (Energetic)" },
    { id: "Charon", name: "Charon (Deep)" },
    { id: "Fenrir", name: "Fenrir (Soft)" }
  ];

  const modes = [
    { 
      id: "translator", 
      title: "Real-time Translator", 
      description: "Speak in any language, and Gemini will instantly translate and speak back.",
      icon: Languages,
      color: "from-blue-500 to-indigo-600"
    },
    { 
      id: "teacher", 
      title: "Language Teacher", 
      description: "Have a voice chat with a helpful tutor who helps with learning.",
      icon: GraduationCap,
      color: "from-indigo-500 to-purple-600"
    },
    { 
      id: "chat", 
      title: "Free Conversation", 
      description: "Chat freely on any topic with the Live AI agent.",
      icon: Smile,
      color: "from-purple-500 to-pink-600"
    }
  ];

  // Convert Float32 audio samples to signed 16-bit PCM little-endian base64
  const convertFloat32ToPcm16 = (float32Array: Float32Array): string => {
    const buffer = new ArrayBuffer(float32Array.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < float32Array.length; i++) {
      const s = Math.max(-1, Math.min(1, float32Array[i]));
      const pcm = s < 0 ? s * 0x8000 : s * 0x7FFF;
      view.setInt16(i * 2, pcm, true); // little-endian
    }
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Play a 24kHz raw PCM little-endian chunk smoothly
  const playPCM24kHzChunk = (base64Data: string) => {
    try {
      const audioCtx = outputAudioCtxRef.current;
      if (!audioCtx || audioCtx.state === "suspended" || isMuted) return;

      // Decode base64 to ArrayBuffer
      const binary = atob(base64Data);
      const buffer = new ArrayBuffer(binary.length);
      const bytes = new Uint8Array(buffer);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      // Convert 16-bit signed PCM to float32
      const view = new DataView(buffer);
      const samplesCount = buffer.byteLength / 2;
      const float32Data = new Float32Array(samplesCount);
      for (let i = 0; i < samplesCount; i++) {
        const int16 = view.getInt16(i * 2, true);
        float32Data[i] = int16 / (int16 < 0 ? 0x8000 : 0x7FFF);
      }

      // Create an AudioBuffer (24kHz Mono)
      const audioBuffer = audioCtx.createBuffer(1, samplesCount, 24000);
      audioBuffer.getChannelData(0).set(float32Data);

      // Create AudioBufferSourceNode
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);

      // Track active source so we can stop playback if interrupted
      audioSourcesRef.current.push(source);
      source.onended = () => {
        audioSourcesRef.current = audioSourcesRef.current.filter(s => s !== source);
        if (audioSourcesRef.current.length === 0) {
          setIsAssistantSpeaking(false);
        }
      };

      // Gapless scheduler
      const now = audioCtx.currentTime;
      if (nextStartTimeRef.current < now) {
        nextStartTimeRef.current = now + 0.05; // 50ms smooth buffer
      }

      source.start(nextStartTimeRef.current);
      nextStartTimeRef.current += audioBuffer.duration;
      setIsAssistantSpeaking(true);
    } catch (e) {
      console.error("Failed to play audio chunk:", e);
    }
  };

  const handleInterrupt = () => {
    // Stop all scheduled playback immediately
    audioSourcesRef.current.forEach(source => {
      try {
        source.stop();
      } catch (e) {}
    });
    audioSourcesRef.current = [];
    nextStartTimeRef.current = 0;
    setIsAssistantSpeaking(false);
  };

  const startSession = async () => {
    setError(null);
    setIsConnecting(true);
    setLiveTranscription([]);

    try {
      // 1. Request microphone permission first
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      micStreamRef.current = stream;

      // 2. Setup audio contexts
      inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      // 3. Connect WebSocket to our proxy endpoint
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const host = window.location.host;
      const wsUrl = `${protocol}//${host}/api/live?voice=${voice}&mode=${mode}`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnecting(false);
        setIsActive(true);
        setLiveTranscription(["System: Session started. Speak into your microphone!"]);

        // Start processing mic input once connected
        setupMicProcessor(stream);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          
          if (msg.error) {
            setError(msg.message || "An error occurred during voice conversation.");
            disconnectSession();
            return;
          }

          if (msg.audio) {
            playPCM24kHzChunk(msg.audio);
          }

          if (msg.text) {
            setLiveTranscription(prev => {
              // Append to the last line if appropriate or create a new line
              const lastLine = prev[prev.length - 1] || "";
              if (lastLine.startsWith("Gemini: ") && !lastLine.endsWith(".")) {
                return [...prev.slice(0, -1), lastLine + " " + msg.text];
              } else if (lastLine.startsWith("Gemini: ")) {
                return [...prev.slice(0, -1), lastLine + msg.text];
              }
              return [...prev, `Gemini: ${msg.text}`];
            });
          }

          if (msg.interrupted) {
            handleInterrupt();
            setLiveTranscription(prev => [...prev, "* Interrupted *"]);
          }
        } catch (e) {
          console.error("Error handling WebSocket message:", e);
        }
      };

      ws.onerror = (e) => {
        console.error("Live session WebSocket error:", e);
        setError("Could not connect to voice conversation server.");
        disconnectSession();
      };

      ws.onclose = () => {
        disconnectSession();
      };

    } catch (err: any) {
      console.error("Error starting voice session:", err);
      setError(err?.message || "Failed to access microphone or initialize audio contexts.");
      setIsConnecting(false);
      disconnectSession();
    }
  };

  const setupMicProcessor = (stream: MediaStream) => {
    const inputCtx = inputAudioCtxRef.current;
    if (!inputCtx) return;

    const source = inputCtx.createMediaStreamSource(stream);
    // Use ScriptProcessorNode for wide browser support of direct PCM data capture
    const processor = inputCtx.createScriptProcessor(4096, 1, 1);
    processorNodeRef.current = processor;

    source.connect(processor);
    processor.connect(inputCtx.destination);

    processor.onaudioprocess = (e) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN || isMuted) return;

      const channelData = e.inputBuffer.getChannelData(0);
      const base64Audio = convertFloat32ToPcm16(channelData);
      
      ws.send(JSON.stringify({ audio: base64Audio }));
    };
  };

  const disconnectSession = () => {
    setIsActive(false);
    setIsConnecting(false);
    setIsAssistantSpeaking(false);

    // Stop and clear audio playback
    handleInterrupt();

    // Close WebSocket
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {}
      wsRef.current = null;
    }

    // Stop Mic Stream
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }

    // Disconnect processor node
    if (processorNodeRef.current) {
      try {
        processorNodeRef.current.disconnect();
      } catch (e) {}
      processorNodeRef.current = null;
    }

    // Close Audio Contexts
    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch (e) {}
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      try {
        outputAudioCtxRef.current.close();
      } catch (e) {}
      outputAudioCtxRef.current = null;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (!isMuted) {
      handleInterrupt();
    }
  };

  return (
    <div id="voice-conversation-container" className="w-full flex flex-col space-y-6">
      
      {/* Modes Grid Selector */}
      {!isActive && !isConnecting && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {modes.map((m) => {
            const Icon = m.icon;
            const isSelected = mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`relative overflow-hidden p-5 rounded-2xl border text-left cursor-pointer transition-all duration-300 ${
                  isSelected 
                    ? "border-blue-500/50 bg-blue-50/50 dark:bg-blue-950/10 shadow-md ring-1 ring-blue-500/20" 
                    : "border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700 bg-white/45 dark:bg-gray-950/30"
                }`}
              >
                {/* Glowing subtle gradient accent for selected mode */}
                {isSelected && (
                  <div className={`absolute -right-12 -top-12 w-24 h-24 rounded-full bg-gradient-to-br ${m.color} opacity-10 blur-xl`} />
                )}
                
                <div className={`p-2.5 rounded-xl w-fit ${
                  isSelected 
                    ? "bg-blue-500/10 text-blue-600 dark:text-blue-400" 
                    : "bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                }`}>
                  <Icon className="w-5 h-5" />
                </div>
                
                <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200 mt-4">{m.title}</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1.5 leading-relaxed font-medium">{m.description}</p>
              </button>
            );
          })}
        </div>
      )}

      {/* Connection & Conversation Panel */}
      <div className="relative overflow-hidden bg-white/70 dark:bg-gray-900/40 backdrop-blur-xl border border-gray-100 dark:border-gray-800 rounded-3xl p-6 shadow-md">
        
        {/* Glow effect on live call */}
        {isActive && (
          <div className="absolute top-0 right-0 p-4">
            <span className="flex h-3 w-3 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
          </div>
        )}

        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Audio Visualizer & Call Controls */}
          <div className="flex flex-col items-center justify-center space-y-4 w-full md:w-1/3">
            
            {/* Visualizer Circle */}
            <div className="relative w-40 h-40 flex items-center justify-center">
              
              {/* Outer pulsing rings */}
              {isActive && !isMuted && (
                <>
                  <motion.div 
                    animate={{ scale: [1, 1.4, 1], opacity: [0.15, 0, 0.15] }}
                    transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                    className={`absolute inset-0 rounded-full bg-blue-500/20 blur-sm`}
                  />
                  <motion.div 
                    animate={{ scale: [1, 1.7, 1], opacity: [0.1, 0, 0.1] }}
                    transition={{ repeat: Infinity, duration: 3, ease: "easeInOut", delay: 0.5 }}
                    className={`absolute inset-0 rounded-full bg-blue-500/10 blur-md`}
                  />
                </>
              )}

              {/* Speech ring */}
              {isAssistantSpeaking && (
                <motion.div 
                  animate={{ scale: [1, 1.2, 1], rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                  className="absolute inset-2 rounded-full border-2 border-dashed border-indigo-400/50"
                />
              )}

              {/* Inner core button */}
              <motion.button
                id="voice-call-control-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={isActive ? disconnectSession : startSession}
                disabled={isConnecting}
                className={`relative w-28 h-28 rounded-full flex flex-col items-center justify-center shadow-lg cursor-pointer border transition-all duration-300 ${
                  isActive 
                    ? "bg-red-500 hover:bg-red-600 text-white border-red-600/30 shadow-red-500/20" 
                    : "bg-blue-600 hover:bg-blue-700 text-white border-blue-700/30 shadow-blue-500/20"
                }`}
              >
                {isConnecting ? (
                  <RefreshCcw className="w-8 h-8 animate-spin" />
                ) : isActive ? (
                  <StopCircle className="w-8 h-8" />
                ) : (
                  <Mic className="w-8 h-8" />
                )}
                <span className="text-[10px] font-bold uppercase tracking-wider mt-2">
                  {isConnecting ? "Connecting" : isActive ? "End Call" : "Start Voice"}
                </span>
              </motion.button>

            </div>

            {/* In-Call controls */}
            {isActive && (
              <div className="flex items-center gap-3">
                
                {/* Mute Mic */}
                <motion.button
                  id="mute-mic-btn"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={toggleMute}
                  className={`p-3 rounded-full border cursor-pointer transition-colors ${
                    isMuted 
                      ? "bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20" 
                      : "bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 border-transparent"
                  }`}
                  title={isMuted ? "Unmute microphone" : "Mute microphone"}
                >
                  {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </motion.button>

                {/* Assistant Audio indicators */}
                <div className={`p-3 rounded-full border ${
                  isAssistantSpeaking 
                    ? "bg-indigo-500/10 text-indigo-500 border-indigo-500/20" 
                    : "bg-gray-100 dark:bg-gray-800 text-gray-400 border-transparent"
                }`}>
                  {isAssistantSpeaking ? <Volume2 className="w-4 h-4 animate-bounce" /> : <VolumeX className="w-4 h-4" />}
                </div>

              </div>
            )}

            {/* Settings Selection when idle */}
            {!isActive && !isConnecting && (
              <div className="flex flex-col space-y-2 w-full max-w-[200px]">
                <label className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase font-mono">Select voice</label>
                <select
                  value={voice}
                  onChange={(e) => setVoice(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 text-xs font-semibold text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                >
                  {voices.map(v => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>
              </div>
            )}

          </div>

          {/* Running Live Transcription Panel */}
          <div className="w-full md:w-2/3 flex flex-col h-48 md:h-60 bg-gray-50/50 dark:bg-gray-950/20 border border-gray-100 dark:border-gray-900 rounded-2xl p-4 overflow-hidden">
            
            <div className="flex items-center gap-1.5 border-b border-gray-100 dark:border-gray-900 pb-2 mb-2">
              <Radio className={`w-3.5 h-3.5 ${isActive ? "text-red-500 animate-pulse" : "text-gray-400"}`} />
              <span className="text-[10px] font-bold tracking-wider uppercase font-mono text-gray-400 dark:text-gray-500">Live Transcript log</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
              <AnimatePresence initial={false}>
                {liveTranscription.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-center text-gray-400 dark:text-gray-500 italic py-8">
                    {isConnecting ? "Connecting to Gemini Live..." : "Voice session inactive. Start a call to begin speaking."}
                  </div>
                ) : (
                  liveTranscription.map((line, idx) => {
                    const isSystem = line.startsWith("System: ");
                    const isUser = line.startsWith("User: ");
                    const isInterrupted = line.includes("* Interrupted *");
                    
                    let content = line;
                    let prefix = "";
                    if (line.startsWith("Gemini: ")) {
                      prefix = "Gemini: ";
                      content = line.replace("Gemini: ", "");
                    } else if (line.startsWith("System: ")) {
                      prefix = "System: ";
                      content = line.replace("System: ", "");
                    }

                    return (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`leading-relaxed rounded-xl p-2.5 ${
                          isSystem 
                            ? "bg-gray-100 dark:bg-gray-800/50 text-gray-500 font-medium" 
                            : isInterrupted 
                            ? "text-red-500 dark:text-red-400 italic font-bold border border-red-500/10 bg-red-500/5"
                            : prefix === "Gemini: "
                            ? "bg-indigo-50/50 dark:bg-indigo-950/10 border border-indigo-100/40 dark:border-indigo-900/10 text-indigo-900 dark:text-indigo-200 font-semibold"
                            : "bg-blue-50/50 dark:bg-blue-950/10 border border-blue-100/40 dark:border-blue-900/10 text-blue-900 dark:text-blue-200 font-medium"
                        }`}
                      >
                        {prefix && <span className="font-bold opacity-70 mr-1">{prefix}</span>}
                        <span>{content}</span>
                      </motion.div>
                    );
                  })
                )}
              </AnimatePresence>
              <div ref={transcriptionEndRef} />
            </div>

          </div>

        </div>

        {/* Error notification */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 p-3 mt-4 rounded-xl border border-red-200/50 dark:border-red-900/40 bg-red-50/40 dark:bg-red-950/10 text-red-600 dark:text-red-400 text-xs font-semibold"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </motion.div>
        )}

      </div>

    </div>
  );
}
