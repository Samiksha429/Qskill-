import { motion, AnimatePresence } from "motion/react";
import { Clock, Trash2, Copy, ArrowRight, CornerDownRight, Check, History as HistoryIcon, Calendar, LogIn, Download } from "lucide-react";
import { useState } from "react";
import { TranslationHistoryItem, Language } from "../types";
import { LANGUAGES } from "./Translator";
import { User } from "firebase/auth";

interface HistoryProps {
  history: TranslationHistoryItem[];
  onDeleteHistory: (id: string) => void;
  onClearHistory: () => void;
  onSelectHistoryItem?: (item: TranslationHistoryItem) => void;
  user?: User | null;
  onSignIn?: () => void;
  loading?: boolean;
}

export default function History({ 
  history, 
  onDeleteHistory, 
  onClearHistory, 
  onSelectHistoryItem,
  user,
  onSignIn,
  loading
}: HistoryProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const getLanguageDetails = (code: string): Language => {
    return LANGUAGES.find((l) => l.code === code) || { code, name: code, flag: "🌐" };
  };

  const handleCopy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1500);
    } catch (e) {
      console.error(e);
    }
  };

  const handleExportCSV = () => {
    try {
      // CSV Headers
      const headers = ["ID", "Original Text", "Translated Text", "From Language", "To Language", "Timestamp"];
      
      // Helper to escape double quotes and wrap values in quotes if they contain quotes, commas, or newlines
      const escapeCsvValue = (val: string) => {
        if (val === undefined || val === null) return '""';
        // Clean line breaks to keep each history item on a single line in CSV
        const stringified = String(val).replace(/\r?\n|\r/g, " ");
        const escaped = stringified.replace(/"/g, '""');
        if (escaped.includes(',') || escaped.includes('"') || escaped.includes(';')) {
          return `"${escaped}"`;
        }
        return escaped;
      };

      // Rows
      const rows = history.map((item) => [
        escapeCsvValue(item.id),
        escapeCsvValue(item.originalText),
        escapeCsvValue(item.translatedText),
        escapeCsvValue(item.fromLang),
        escapeCsvValue(item.toLang),
        escapeCsvValue(item.timestamp)
      ]);

      // Combine headers and rows
      const csvContent = [
        headers.join(","),
        ...rows.map((row) => row.join(","))
      ].join("\n");

      // Create a Blob and download it with UTF-8 BOM so Excel opens non-English characters with correct encoding
      const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `translation_history_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Failed to export history to CSV:", error);
    }
  };

  return (
    <div id="translation-history" className="w-full h-full flex flex-col scroll-mt-20">
      
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5 pb-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900/40">
            <HistoryIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-800 dark:text-gray-100">Translation History</h3>
            <p className="text-xs text-gray-400 dark:text-gray-500 font-medium">
              {user ? "Synced securely with Google Cloud" : "Last 10 queries stored locally"}
            </p>
          </div>
        </div>

        {history.length > 0 && (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <motion.button
              id="export-history-csv-btn"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={(e) => {
                e.stopPropagation();
                handleExportCSV();
              }}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/30 dark:hover:bg-emerald-900/30 border border-emerald-200/60 dark:border-emerald-900/40 text-emerald-600 dark:text-emerald-400 cursor-pointer transition-colors"
              title="Export saved translations as CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </motion.button>

            <motion.button
              id="clear-all-history-btn"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onClearHistory}
              className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-900 text-gray-600 dark:text-gray-400 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear All</span>
            </motion.button>
          </div>
        )}
      </div>

      {/* Cloud Sync Promo Banner */}
      {!user && onSignIn && (
        <div className="mb-5 p-4 rounded-2xl border border-blue-100 dark:border-blue-950/50 bg-blue-50/30 dark:bg-blue-950/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <p className="text-xs font-bold text-blue-950 dark:text-blue-200">Keep history safe across devices</p>
            <p className="text-[10px] text-blue-700/80 dark:text-blue-400/80 leading-relaxed">Sign in with Google to back up your translations and sync them securely in Firestore.</p>
          </div>
          <button
            id="history-signin-promo-btn"
            onClick={onSignIn}
            className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold shadow-sm cursor-pointer transition-colors"
          >
            <LogIn className="w-3 h-3" />
            <span>Sign In</span>
          </button>
        </div>
      )}

      {/* History List */}
      <div className="relative flex-1 overflow-y-auto max-h-[640px] pr-1.5 space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-8 h-8 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" />
            <p className="text-xs text-gray-400 dark:text-gray-500 font-semibold">Syncing translation logs...</p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {history.length === 0 ? (
              <motion.div
                id="empty-history-state"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-12 px-4 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 bg-gray-50/20 dark:bg-gray-900/5 text-center"
              >
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-900 text-gray-400 mb-3.5">
                  <Clock className="w-5.5 h-5.5" />
                </div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">No translations logged yet</h4>
                <p className="text-xs text-gray-400 dark:text-gray-500 max-w-sm mt-1">Submit translation queries above and they will automatically populate here for quick access.</p>
              </motion.div>
            ) : (
              <div className="space-y-4">
                {history.map((item) => {
                  const srcDetails = getLanguageDetails(item.fromLang);
                  const tgtDetails = getLanguageDetails(item.toLang);

                  return (
                    <motion.div
                      key={item.id}
                      id={`history-item-${item.id}`}
                      initial={{ opacity: 0, x: -10, y: 5 }}
                      animate={{ opacity: 1, x: 0, y: 0 }}
                      exit={{ opacity: 0, x: 20, scale: 0.95 }}
                      transition={{ type: "spring", stiffness: 350, damping: 25 }}
                      onClick={() => onSelectHistoryItem?.(item)}
                      className="p-5 rounded-2xl border border-gray-100 dark:border-gray-800/80 bg-white/50 dark:bg-gray-900/30 hover:bg-white/90 dark:hover:bg-gray-900/60 hover:border-blue-300 dark:hover:border-blue-900/40 hover:shadow-md backdrop-blur-md shadow-xs transition-all duration-300 flex flex-col md:flex-row md:items-start justify-between gap-4 group cursor-pointer"
                    >
                      
                      {/* Log Details Container */}
                      <div className="flex-1 space-y-3.5">
                        
                        {/* Language and timestamp bar */}
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Language Indicators */}
                          <div className="flex items-center gap-1.5 bg-gray-100 dark:bg-gray-800 px-2.5 py-1 rounded-lg text-xs font-semibold text-gray-700 dark:text-gray-300">
                            <span>{srcDetails.flag}</span>
                            <span className="truncate max-w-[80px]">{srcDetails.name}</span>
                            <ArrowRight className="w-3 h-3 text-gray-400" />
                            <span>{tgtDetails.flag}</span>
                            <span className="truncate max-w-[80px]">{tgtDetails.name}</span>
                          </div>

                          {/* Timestamp */}
                          <div className="flex items-center gap-1 text-[10px] font-medium text-gray-400 dark:text-gray-500 ml-auto md:ml-0">
                            <Calendar className="w-3 h-3" />
                            <span>{item.timestamp}</span>
                          </div>
                        </div>

                        {/* Text Outputs Block */}
                        <div className="space-y-2">
                          {/* Original Text */}
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400 leading-relaxed truncate max-w-2xl">
                            {item.originalText}
                          </p>
                          
                          {/* Translated Text */}
                          <div className="flex items-start gap-2 text-sm font-semibold text-gray-800 dark:text-gray-100 leading-relaxed bg-blue-50/30 dark:bg-blue-950/10 p-3 rounded-xl border border-blue-500/5 group-hover:bg-blue-500/5 dark:group-hover:bg-blue-500/10 transition-colors">
                            <CornerDownRight className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                            <p className="flex-1">{item.translatedText}</p>
                          </div>
                        </div>

                      </div>

                      {/* Log Actions Area */}
                      <div className="flex items-center md:flex-col gap-2 border-t md:border-t-0 border-gray-100 dark:border-gray-800/40 pt-3 md:pt-0 self-stretch md:self-auto justify-end">
                        
                        {/* Quick copy translation */}
                        <button
                          id={`copy-history-${item.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCopy(item.translatedText, item.id);
                          }}
                          className={`flex-1 md:flex-none p-2.5 rounded-xl border border-gray-200/50 dark:border-gray-800/60 bg-white dark:bg-gray-950 text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 shadow-2xs hover:bg-gray-50 cursor-pointer transition-all flex items-center justify-center gap-2`}
                          title="Copy Translation"
                        >
                          {copiedId === item.id ? (
                            <>
                              <Check className="w-4 h-4 text-emerald-500" />
                              <span className="md:hidden text-xs font-semibold text-emerald-500">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              <span className="md:hidden text-xs font-semibold">Copy Output</span>
                            </>
                          )}
                        </button>

                        {/* Delete record */}
                        <button
                          id={`delete-history-${item.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteHistory(item.id);
                          }}
                          className="flex-1 md:flex-none p-2.5 rounded-xl border border-gray-200/50 dark:border-gray-800/60 bg-white dark:bg-gray-950 text-gray-500 dark:text-gray-400 hover:text-rose-500 hover:border-rose-100 hover:bg-rose-50/50 dark:hover:bg-rose-950/20 shadow-2xs cursor-pointer transition-all flex items-center justify-center gap-2"
                          title="Delete log"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span className="md:hidden text-xs font-semibold">Delete Entry</span>
                        </button>

                      </div>

                    </motion.div>
                  );
                })}
              </div>
            )}
          </AnimatePresence>
        )}
      </div>

    </div>
  );
}
