import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ArrowLeftRight, 
  Copy, 
  Download, 
  Volume2, 
  Trash2, 
  Sparkles, 
  Loader2, 
  Check, 
  AlertCircle, 
  HelpCircle,
  FileText,
  VolumeX,
  Keyboard,
  Cpu
} from "lucide-react";
import { translateText } from "../services/translatorApi";
import { Language, TranslationHistoryItem } from "../types";
import SearchableDropdown from "./SearchableDropdown";

// Supported languages configurations with flag representation
export const LANGUAGES: Language[] = [
  { code: "af", name: "Afrikaans", flag: "🇿🇦" },
  { code: "sq", name: "Albanian", flag: "🇦🇱" },
  { code: "ar", name: "Arabic", flag: "🇸🇦" },
  { code: "hy", name: "Armenian", flag: "🇦🇲" },
  { code: "az", name: "Azerbaijani", flag: "🇦🇿" },
  { code: "eu", name: "Basque", flag: "🇪🇸" },
  { code: "be", name: "Belarusian", flag: "🇧🇾" },
  { code: "bn", name: "Bengali", flag: "🇧🇩" },
  { code: "bs", name: "Bosnian", flag: "🇧🇦" },
  { code: "bg", name: "Bulgarian", flag: "🇧🇬" },
  { code: "ca", name: "Catalan", flag: "🇪🇸" },
  { code: "zh", name: "Chinese (Simplified)", flag: "🇨🇳" },
  { code: "hr", name: "Croatian", flag: "🇭🇷" },
  { code: "cs", name: "Czech", flag: "🇨🇿" },
  { code: "da", name: "Danish", flag: "🇩🇰" },
  { code: "nl", name: "Dutch", flag: "🇳🇱" },
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "eo", name: "Esperanto", flag: "🌍" },
  { code: "et", name: "Estonian", flag: "🇪🇪" },
  { code: "fi", name: "Finnish", flag: "🇫🇮" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "gl", name: "Galician", flag: "🇪🇸" },
  { code: "ka", name: "Georgian", flag: "🇬🇪" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "el", name: "Greek", flag: "🇬🇷" },
  { code: "gu", name: "Gujarati", flag: "🇮🇳" },
  { code: "ht", name: "Haitian Creole", flag: "🇭🇹" },
  { code: "he", name: "Hebrew", flag: "🇮🇱" },
  { code: "hi", name: "Hindi", flag: "🇮🇳" },
  { code: "hu", name: "Hungarian", flag: "🇭🇺" },
  { code: "is", name: "Icelandic", flag: "🇮🇸" },
  { code: "id", name: "Indonesian", flag: "🇮🇩" },
  { code: "ga", name: "Irish", flag: "🇮🇪" },
  { code: "it", name: "Italian", flag: "🇮🇹" },
  { code: "ja", name: "Japanese", flag: "🇯🇵" },
  { code: "kn", name: "Kannada", flag: "🇮🇳" },
  { code: "kk", name: "Kazakh", flag: "🇰🇿" },
  { code: "ko", name: "Korean", flag: "🇰🇷" },
  { code: "lv", name: "Latvian", flag: "🇱🇻" },
  { code: "lt", name: "Lithuanian", flag: "🇱🇹" },
  { code: "mk", name: "Macedonian", flag: "🇲🇰" },
  { code: "ms", name: "Malay", flag: "🇲🇾" },
  { code: "ml", name: "Malayalam", flag: "🇮🇳" },
  { code: "mt", name: "Maltese", flag: "🇲🇹" },
  { code: "mr", name: "Marathi", flag: "🇮🇳" },
  { code: "mn", name: "Mongolian", flag: "🇲🇳" },
  { code: "ne", name: "Nepali", flag: "🇳🇵" },
  { code: "no", name: "Norwegian", flag: "🇳🇴" },
  { code: "fa", name: "Persian", flag: "🇮🇷" },
  { code: "pl", name: "Polish", flag: "🇵🇱" },
  { code: "pt", name: "Portuguese", flag: "🇵🇹" },
  { code: "pa", name: "Punjabi", flag: "🇮🇳" },
  { code: "ro", name: "Romanian", flag: "🇷🇴" },
  { code: "ru", name: "Russian", flag: "🇷🇺" },
  { code: "sr", name: "Serbian", flag: "🇷🇸" },
  { code: "sk", name: "Slovak", flag: "🇸🇰" },
  { code: "sl", name: "Slovenian", flag: "🇸🇮" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "sw", name: "Swahili", flag: "🇰🇪" },
  { code: "sv", name: "Swedish", flag: "🇸🇪" },
  { code: "ta", name: "Tamil", flag: "🇮🇳" },
  { code: "te", name: "Telugu", flag: "🇮🇳" },
  { code: "th", name: "Thai", flag: "🇹🇭" },
  { code: "tr", name: "Turkish", flag: "🇹🇷" },
  { code: "uk", name: "Ukrainian", flag: "🇺🇦" },
  { code: "ur", name: "Urdu", flag: "🇵🇰" },
  { code: "vi", name: "Vietnamese", flag: "🇻🇳" },
  { code: "cy", name: "Welsh", flag: "🇬🇧" },
  { code: "yi", name: "Yiddish", flag: "🌍" },
  { code: "zu", name: "Zulu", flag: "🇿🇦" }
];

interface TranslatorProps {
  onAddHistory: (item: Omit<TranslationHistoryItem, "id" | "timestamp">) => void;
  revisitItem?: TranslationHistoryItem | null;
  onClearRevisit?: () => void;
}

export default function Translator({ onAddHistory, revisitItem, onClearRevisit }: TranslatorProps) {
  const [inputText, setInputText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("fr");
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<{ type: string; message: string } | null>(null);
  
  // Custom Toast Notifications
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  
  // TTS voice state
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const maxChars = 5000;

  const [engine, setEngine] = useState<"auto" | "gemini" | "microsoft">(() => {
    try {
      const saved = localStorage.getItem("translation_engine");
      if (saved === "auto" || saved === "gemini" || saved === "microsoft") {
        return saved as "auto" | "gemini" | "microsoft";
      }
      return "auto";
    } catch (e) {
      return "auto";
    }
  });

  // Sync engine preference to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("translation_engine", engine);
    } catch (e) {
      console.error(e);
    }
  }, [engine]);

  // Clear states
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Clean speaking state if window.speechSynthesis ends or is canceled, or if HTML5 Audio finishes
  useEffect(() => {
    const handleSpeechState = () => {
      if (!isSpeaking) return;
      if (audioRef.current) {
        if (audioRef.current.ended || audioRef.current.paused) {
          setIsSpeaking(false);
        }
      } else if (window.speechSynthesis && !window.speechSynthesis.speaking) {
        setIsSpeaking(false);
      }
    };

    const interval = setInterval(handleSpeechState, 500);
    return () => clearInterval(interval);
  }, [isSpeaking]);

  // Handle loading a selected history item back into the workspace
  useEffect(() => {
    if (revisitItem) {
      setInputText(revisitItem.originalText);
      setTranslatedText(revisitItem.translatedText);
      setSourceLang(revisitItem.fromLang);
      setTargetLang(revisitItem.toLang);
      setError(null);
      triggerToast("Loaded translation from history", "success");
      onClearRevisit?.();
    }
  }, [revisitItem, onClearRevisit]);

  const triggerToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) {
      const sourceLangName = LANGUAGES.find(l => l.code === sourceLang)?.name || "source language";
      setError({ type: "validation", message: `Please enter text in the ${sourceLangName} field.` });
      return;
    }

    if (inputText.length > maxChars) {
      setError({ type: "validation", message: `Text exceeds the maximum limit of ${maxChars} characters.` });
      return;
    }

    setIsLoading(true);
    setError(null);
    setTranslatedText("");

    try {
      const res = await translateText(inputText, sourceLang, targetLang, engine);
      
      if (res.error) {
        if (res.error === "API_KEY_MISSING") {
          setError({
            type: "api_key",
            message: "RapidAPI translation key is missing. Please configure 'VITE_RAPIDAPI_KEY' in your secrets configuration."
          });
          triggerToast("API Key Config Missing", "error");
        } else {
          setError({
            type: "api",
            message: res.message || "An unexpected translation failure occurred."
          });
          triggerToast(res.message || "Translation failed", "error");
        }
      } else {
        setTranslatedText(res.translation);
        triggerToast("Translated successfully!", "success");
        
        // Save to translation history via callback
        onAddHistory({
          originalText: inputText.trim(),
          translatedText: res.translation,
          fromLang: sourceLang,
          toLang: targetLang
        });
      }
    } catch (err: any) {
      setError({
        type: "network",
        message: err.message || "A network failure occurred. Please inspect developer settings."
      });
      triggerToast("Network/Connection failure", "error");
    } finally {
      setIsLoading(false);
    }
  };

  // Swaps translation states (from language and text outputs)
  const handleSwap = () => {
    const tempLang = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(tempLang);

    const tempText = inputText;
    setInputText(translatedText);
    setTranslatedText(tempText);
    
    setError(null);
    triggerToast("Swapped languages and inputs", "info");
  };

  const handleClear = () => {
    setInputText("");
    setTranslatedText("");
    setError(null);
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
    triggerToast("Cleared translation workspace", "info");
  };

  const copyToClipboard = async (text: string) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      triggerToast("Copied translation to clipboard!", "success");
    } catch (err) {
      triggerToast("Clipboard access failed", "error");
    }
  };

  const downloadTextAsFile = () => {
    if (!translatedText) return;
    try {
      const element = document.createElement("a");
      const file = new Blob([
        `=== LINGUATRANSLATE DOCUMENT ===\n`,
        `Source (${LANGUAGES.find(l => l.code === sourceLang)?.name}): ${inputText}\n`,
        `Translated (${LANGUAGES.find(l => l.code === targetLang)?.name}): ${translatedText}\n`,
        `\nExported on: ${new Date().toLocaleString()}`
      ], { type: "text/plain;charset=utf-8" });
      
      element.href = URL.createObjectURL(file);
      element.download = `translation-${sourceLang}-to-${targetLang}.txt`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      triggerToast("Downloaded translation as TXT", "success");
    } catch (e) {
      triggerToast("Failed to compile TXT file", "error");
    }
  };

  // Global Keyboard Shortcuts (Ctrl+Enter to translate, Ctrl+S to save/download)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isModifier = e.ctrlKey || e.metaKey;
      if (isModifier) {
        if (e.key === "Enter") {
          e.preventDefault();
          handleTranslate();
        } else if (e.key.toLowerCase() === "s") {
          e.preventDefault();
          if (translatedText) {
            downloadTextAsFile();
          } else {
            triggerToast("No translation available to save", "error");
          }
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [inputText, translatedText, sourceLang, targetLang, engine]);

  const playCloudTts = (text: string, langCode: string) => {
    try {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      const url = `/api/tts?text=${encodeURIComponent(text)}&lang=${encodeURIComponent(langCode)}`;
      const audio = new Audio(url);
      audioRef.current = audio;
      setIsSpeaking(true);
      audio.play().catch((err) => {
        console.error("Cloud TTS playback failed, attempting native default fallback:", err);
        // Last-resort fallback to standard speechSynthesis if audio element block by browser autoplay policies
        if (window.speechSynthesis) {
          try {
            const fallbackUtterance = new SpeechSynthesisUtterance(text);
            fallbackUtterance.lang = langCode;
            fallbackUtterance.onend = () => setIsSpeaking(false);
            fallbackUtterance.onerror = () => setIsSpeaking(false);
            window.speechSynthesis.speak(fallbackUtterance);
          } catch (speechErr) {
            setIsSpeaking(false);
          }
        } else {
          setIsSpeaking(false);
          triggerToast("Playback blocked by browser settings.", "error");
        }
      });
      audio.onended = () => {
        setIsSpeaking(false);
        audioRef.current = null;
      };
      audio.onerror = (err) => {
        console.error("Cloud TTS loading failed:", err);
        setIsSpeaking(false);
        audioRef.current = null;
        triggerToast("Cloud speech is temporarily busy.", "error");
      };
    } catch (e) {
      console.error(e);
      setIsSpeaking(false);
    }
  };

  const handleTextToSpeech = (text: string, langCode: string) => {
    if (isSpeaking) {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setIsSpeaking(false);
      return;
    }

    if (!window.speechSynthesis) {
      playCloudTts(text, langCode);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Comprehensive BCP-47 locale map for all 70 languages
    const localeMap: Record<string, string> = {
      af: "af-ZA",
      sq: "sq-AL",
      ar: "ar-SA",
      hy: "hy-AM",
      az: "az-AZ",
      eu: "eu-ES",
      be: "be-BY",
      bn: "bn-IN",
      bs: "bs-BA",
      bg: "bg-BG",
      ca: "ca-ES",
      zh: "zh-CN",
      hr: "hr-HR",
      cs: "cs-CZ",
      da: "da-DK",
      nl: "nl-NL",
      en: "en-US",
      eo: "eo",
      et: "et-EE",
      fi: "fi-FI",
      fr: "fr-FR",
      gl: "gl-ES",
      ka: "ka-GE",
      de: "de-DE",
      el: "el-GR",
      gu: "gu-IN",
      ht: "ht-HT",
      he: "he-IL",
      hi: "hi-IN",
      hu: "hu-HU",
      is: "is-IS",
      id: "id-ID",
      ga: "ga-IE",
      it: "it-IT",
      ja: "ja-JP",
      kn: "kn-IN",
      kk: "kk-KZ",
      ko: "ko-KR",
      lv: "lv-LV",
      lt: "lt-LT",
      mk: "mk-MK",
      ms: "ms-MY",
      ml: "ml-IN",
      mt: "mt-MT",
      mr: "mr-IN",
      mn: "mn-MN",
      ne: "ne-NP",
      no: "no-NO",
      fa: "fa-IR",
      pl: "pl-PL",
      pt: "pt-PT",
      pa: "pa-IN",
      ro: "ro-RO",
      ru: "ru-RU",
      sr: "sr-RS",
      sk: "sk-SK",
      sl: "sl-SI",
      es: "es-ES",
      sw: "sw-KE",
      sv: "sv-SE",
      ta: "ta-IN",
      te: "te-IN",
      th: "th-TH",
      tr: "tr-TR",
      uk: "uk-UA",
      ur: "ur-PK",
      vi: "vi-VN",
      cy: "cy-GB",
      yi: "yi",
      zu: "zu-ZA"
    };

    const targetLocale = localeMap[langCode] || langCode;
    utterance.lang = targetLocale;

    // Dynamically query available native speech voices to match the locale
    const voices = window.speechSynthesis.getVoices();
    
    // 1. Try to find an exact locale match (e.g. "hi-IN", "en-US")
    let bestVoice = voices.find(
      v => v.lang.replace("_", "-").toLowerCase() === targetLocale.toLowerCase()
    );

    // 2. Fallback to matching language prefix with a regional delimiter (e.g., "en-")
    if (!bestVoice) {
      bestVoice = voices.find(
        v => v.lang.toLowerCase().startsWith(langCode.toLowerCase() + "-")
      );
    }

    // 3. Fallback to exact 2-letter language code match
    if (!bestVoice) {
      bestVoice = voices.find(
        v => v.lang.toLowerCase() === langCode.toLowerCase()
      );
    }

    // 4. Fallback to loose inclusion
    if (!bestVoice) {
      bestVoice = voices.find(
        v => v.lang.toLowerCase().includes(langCode.toLowerCase())
      );
    }

    // If matching system voice was found, bind it explicitly to guarantee correct playback
    if (bestVoice) {
      utterance.voice = bestVoice;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (e) => {
        console.warn("SpeechSynthesis error, falling back to Cloud TTS:", e);
        playCloudTts(text, langCode);
      };
      
      speechRef.current = utterance;
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } else {
      // No high-quality local voice available, use high-fidelity Cloud TTS!
      playCloudTts(text, langCode);
    }
  };

  // Word counter calculation
  const getWordCount = (text: string) => {
    const trimmed = text.trim();
    return trimmed === "" ? 0 : trimmed.split(/\s+/).length;
  };

  return (
    <div id="translator-card" className="w-full">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-18 right-4 md:right-8 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border backdrop-blur-md text-sm ${
              toast.type === "success" 
                ? "bg-emerald-50/90 dark:bg-emerald-950/90 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-900/50"
                : toast.type === "error"
                ? "bg-rose-50/90 dark:bg-rose-950/90 text-rose-800 dark:text-rose-200 border-rose-200 dark:border-rose-900/50"
                : "bg-blue-50/90 dark:bg-blue-950/90 text-blue-800 dark:text-blue-200 border-blue-200 dark:border-blue-900/50"
            }`}
          >
            {toast.type === "success" ? <Check className="w-4 h-4 text-emerald-500" /> : <AlertCircle className="w-4 h-4 text-rose-500" />}
            <span className="font-medium">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative overflow-hidden rounded-3xl border border-gray-100 dark:border-gray-800 bg-white/70 dark:bg-gray-900/40 backdrop-blur-xl shadow-xl transition-all duration-300">
        
        {/* Background ambient mesh */}
        <div className="absolute top-0 right-0 -mr-24 -mt-24 w-80 h-80 rounded-full bg-blue-400/10 dark:bg-blue-500/5 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-80 h-80 rounded-full bg-indigo-400/10 dark:bg-indigo-500/5 blur-3xl pointer-events-none" />

        {/* Workspace Toolbar / Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/20">
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Source Selector */}
            <div className="relative flex-1 sm:flex-none">
              <label htmlFor="source-lang-select" className="sr-only">Source Language</label>
              <SearchableDropdown
                id="source-lang-select"
                value={sourceLang}
                onChange={setSourceLang}
                options={LANGUAGES}
                placeholder="Search source language..."
              />
            </div>

            {/* Swap Button */}
            <motion.button
              id="swap-languages-btn"
              whileTap={{ scale: 0.9, rotate: 180 }}
              whileHover={{ scale: 1.05 }}
              onClick={handleSwap}
              className="p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 text-gray-600 dark:text-gray-300 shadow-sm cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              title="Swap Languages"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </motion.button>

            {/* Target Selector */}
            <div className="relative flex-1 sm:flex-none">
              <label htmlFor="target-lang-select" className="sr-only">Target Language</label>
              <SearchableDropdown
                id="target-lang-select"
                value={targetLang}
                onChange={setTargetLang}
                options={LANGUAGES}
                placeholder="Search target language..."
              />
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            {/* Engine Selector */}
            <div className="relative flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 text-gray-700 dark:text-gray-300 shadow-sm">
              <Cpu className="w-3.5 h-3.5 text-blue-500" />
              <select
                id="engine-select"
                value={engine}
                onChange={(e) => {
                  const val = e.target.value as "auto" | "gemini" | "microsoft";
                  setEngine(val);
                  triggerToast(`Engine: ${val === "auto" ? "Auto-Detect" : val === "gemini" ? "Gemini AI" : "Microsoft Translator"}`, "info");
                }}
                className="bg-transparent text-xs font-semibold focus:outline-none cursor-pointer pr-1 transition-all"
                title="Select Translation Engine"
              >
                <option value="auto" className="bg-white dark:bg-gray-950">Auto (Prefer MS)</option>
                <option value="gemini" className="bg-white dark:bg-gray-950">Gemini AI (Fast)</option>
                <option value="microsoft" className="bg-white dark:bg-gray-950">Microsoft API</option>
              </select>
            </div>

            {/* Clear Button */}
            <motion.button
              id="clear-inputs-btn"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleClear}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-semibold border border-rose-200/50 dark:border-rose-900/30 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Board</span>
            </motion.button>
          </div>

        </div>

        {/* Translation Panels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-100 dark:divide-gray-800">
          
          {/* Input Panel */}
          <div className="p-5 flex flex-col min-h-[280px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Keyboard className="w-3.5 h-3.5" />
                Input ({LANGUAGES.find(l => l.code === sourceLang)?.name})
              </span>
              <div className="flex items-center gap-2">
                <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-[10px] font-medium text-gray-400 dark:text-gray-500 font-mono">
                  Ctrl+Enter
                </span>
                <span className="text-xs text-gray-400 dark:text-gray-500 font-medium">
                  {getWordCount(inputText)} words
                </span>
              </div>
            </div>

            <label htmlFor="source-text-input" className="sr-only">Text to translate</label>
            <textarea
              id="source-text-input"
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                if (error && error.type === "validation") setError(null);
              }}
              placeholder={`Enter text in ${LANGUAGES.find(l => l.code === sourceLang)?.name}...`}
              maxLength={maxChars}
              className="w-full flex-1 min-h-[180px] bg-transparent text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-600 text-base resize-none focus:outline-none focus:ring-0 border-0 p-0 leading-relaxed"
            />

            <div className="flex items-center justify-between pt-4 border-t border-gray-50 dark:border-gray-800/40 mt-auto">
              {/* Optional Reader for input */}
              <button
                id="source-tts-btn"
                onClick={() => handleTextToSpeech(inputText, sourceLang)}
                disabled={!inputText.trim()}
                className={`p-2 rounded-lg cursor-pointer transition-colors ${
                  inputText.trim() 
                    ? "text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800" 
                    : "text-gray-200 dark:text-gray-800 pointer-events-none"
                }`}
                title="Speak Source Text"
              >
                <Volume2 className="w-4.5 h-4.5" />
              </button>

              <span className={`text-xs font-semibold ${
                inputText.length >= maxChars - 100 
                  ? "text-rose-500 animate-pulse" 
                  : "text-gray-400 dark:text-gray-600"
              }`}>
                {maxChars - inputText.length} chars left
              </span>
            </div>
          </div>

          {/* Output Panel */}
          <div className="p-5 flex flex-col min-h-[280px] bg-gray-50/30 dark:bg-gray-900/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                Translation ({LANGUAGES.find(l => l.code === targetLang)?.name})
              </span>
              {translatedText && (
                <span className="text-xs text-gray-400 dark:text-gray-500 font-medium">
                  Done
                </span>
              )}
            </div>

            <div className="w-full flex-1 min-h-[180px] relative">
              <label htmlFor="translation-output" className="sr-only">Translation output</label>
              <textarea
                id="translation-output"
                readOnly
                value={translatedText}
                placeholder={isLoading ? "Analyzing text structure and translating..." : "Translation output will appear here..."}
                className="w-full h-full bg-transparent text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-700 text-base resize-none focus:outline-none border-0 p-0 leading-relaxed"
              />
              
              {/* Spinner loader layout */}
              {isLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/40 dark:bg-gray-950/40 rounded-xl backdrop-blur-xs">
                  <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                  <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-2.5">
                    {engine === "gemini" 
                      ? "Gemini AI translation model" 
                      : engine === "microsoft" 
                      ? "Microsoft Machine Translation API" 
                      : "Optimized AI translation pipeline"}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-gray-50 dark:border-gray-800/40 mt-auto">
              <div className="flex items-center gap-1">
                {/* Audio Reader */}
                <button
                  id="target-tts-btn"
                  onClick={() => handleTextToSpeech(translatedText, targetLang)}
                  disabled={!translatedText}
                  className={`p-2 rounded-lg cursor-pointer transition-colors ${
                    translatedText 
                      ? isSpeaking 
                        ? "text-rose-500 bg-rose-50 dark:bg-rose-950/20 hover:bg-rose-100" 
                        : "text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                      : "text-gray-200 dark:text-gray-800 pointer-events-none"
                  }`}
                  title={isSpeaking ? "Stop Speaking" : "Listen to Translation"}
                >
                  {isSpeaking ? <VolumeX className="w-4.5 h-4.5" /> : <Volume2 className="w-4.5 h-4.5" />}
                </button>

                {/* Copy to Clipboard */}
                <button
                  id="copy-translation-btn"
                  onClick={() => copyToClipboard(translatedText)}
                  disabled={!translatedText}
                  className={`p-2 rounded-lg cursor-pointer transition-colors ${
                    translatedText 
                      ? "text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800" 
                      : "text-gray-200 dark:text-gray-800 pointer-events-none"
                  }`}
                  title="Copy to Clipboard"
                >
                  <Copy className="w-4.5 h-4.5" />
                </button>

                {/* Download as Text File */}
                <button
                  id="download-translation-btn"
                  onClick={downloadTextAsFile}
                  disabled={!translatedText}
                  className={`p-2 rounded-lg cursor-pointer transition-colors ${
                    translatedText 
                      ? "text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800" 
                      : "text-gray-200 dark:text-gray-800 pointer-events-none"
                  }`}
                  title="Download as TXT (Ctrl+S)"
                >
                  <Download className="w-4.5 h-4.5" />
                </button>
              </div>

              {translatedText && (
                <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/30 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Success
                </span>
              )}
            </div>
          </div>

        </div>

        {/* Dynamic Action Trigger Zone */}
        <div className="p-5 bg-gray-50 dark:bg-gray-900/30 border-t border-gray-100 dark:border-gray-800 flex flex-col gap-3">
          
          {/* Detailed Error Toast Inline */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="w-full"
              >
                <div className={`p-4 rounded-xl border flex items-start gap-3 ${
                  error.type === "api_key" 
                    ? "bg-amber-50/80 dark:bg-amber-950/30 border-amber-200/50 dark:border-amber-900/40 text-amber-800 dark:text-amber-200" 
                    : "bg-rose-50/80 dark:bg-rose-950/30 border-rose-200/50 dark:border-rose-900/40 text-rose-800 dark:text-rose-200"
                }`}>
                  <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                    error.type === "api_key" ? "text-amber-500" : "text-rose-500"
                  }`} />
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider">
                      {error.type === "api_key" ? "Configuration Required" : "Translation Request Failed"}
                    </h4>
                    <p className="text-sm mt-0.5 leading-relaxed">{error.message}</p>
                    {error.type === "api_key" && (
                      <div className="mt-2.5 text-xs text-amber-700/80 dark:text-amber-300/80 leading-relaxed bg-amber-100/40 dark:bg-amber-950/50 p-2.5 rounded-lg border border-amber-200/30">
                        <span className="font-semibold">Setup Instructions:</span> Open <b>Settings</b> menu at top-right, go to <b>Secrets</b>, and set <code className="bg-amber-100 dark:bg-gray-950 px-1 py-0.5 rounded font-mono text-amber-800 dark:text-amber-400">VITE_RAPIDAPI_KEY</code> with your real Microsoft Translator key from RapidAPI.
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Trigger Translation Button */}
          <motion.button
            id="translate-submit-btn"
            onClick={handleTranslate}
            disabled={isLoading || !inputText.trim()}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            className={`w-full py-4 px-6 rounded-2xl font-semibold text-base shadow-lg cursor-pointer flex items-center justify-center gap-2.5 transition-all duration-300 ${
              !inputText.trim()
                ? "bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600 cursor-not-allowed shadow-none"
                : "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/10 dark:shadow-indigo-950/30"
            }`}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Processing AI Translation...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-blue-100" />
                <span>Translate to {LANGUAGES.find(l => l.code === targetLang)?.name}</span>
                <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-white/10 dark:bg-black/10 text-[10px] font-mono text-blue-100/90 ml-1 border border-white/10">
                  Ctrl + Enter
                </kbd>
              </>
            )}
          </motion.button>
        </div>

      </div>
    </div>
  );
}
